﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2ndUpTsp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("+");
            comboBox1.Items.Add("-");
            comboBox1.Items.Add("*");    
            comboBox1.Items.Add("/");
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b;
            a = Double.Parse(textBox1.Text);
            b = Double.Parse(textBox2.Text);

            if (comboBox1.Text == "+")
            {
                textBox4.Text = Calc.Addition(a, b).ToString(); 
            }
            if (comboBox1.Text == "-")
            {
                textBox4.Text = Calc.Subtraction(a, b).ToString();
            }
            if (comboBox1.Text == "*")
            {
                textBox4.Text = Calc.Multiplication(a, b).ToString();
            }
            if (comboBox1.Text == "/")
            {
                if (b != 0)
                {
                    textBox4.Text = Calc.Division(a, b).ToString();
                }
                else MessageBox.Show("Can't divide by 0", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.' &&
            e.KeyChar != '-')
            {
                e.Handled = true; textBox1.Focus();
            }
        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.' &&
                e.KeyChar != '-')
                {
                    e.Handled = true; textBox2.Focus();
                }
            }
        }

       
    }
    class Calc
    {
        public static double Addition(double a, double b)
        {
            return a + b;
        }
        public static double Subtraction(double a, double b)
        {
            return a - b;
        }
        public static double Multiplication(double a, double b)
        {
            return a * b;
        }
        public static double Division(double a, double b)
        {
            return a / b;
        }
    }
}
