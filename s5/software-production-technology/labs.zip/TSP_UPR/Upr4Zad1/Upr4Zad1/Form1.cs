﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Upr4Zad1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string[] lines = System.IO.File.ReadAllLines("D:\\21621600\\Toppings.txt");
            foreach (string str in lines)
            {
                checkedListBox1.Items.Add(str);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double br = 0;
            double sum=0;
            string s = "";
            string crust="";
            for (int x = 0; x < checkedListBox1.Items.Count; x++) {
                if(checkedListBox1.GetItemChecked(x)){
                    br++;
                    s = s +checkedListBox1.Items[x].ToString()+", ";
                }
            }
            sum = sum + br;
            if (radioButton1.Checked) {
                sum = sum + 9.25;
            }
            else if (radioButton2.Checked) {
                sum = sum + 11.50;            
            }
            else if (radioButton3.Checked) {
                sum = sum + 13.75;
            }
            if (checkBox1.Checked) {
                sum = sum + 1.50;
            }
            if(radioButton4.Checked){
                crust="thin";
            }
            else 
                crust="thick";

            if (checkBox1.Checked) {
                sum = sum + 1.50;
                richTextBox1.Text = "You ordered a " + crust + " crust pizza with extra cheese and " + br + " toppings: " + s+"\n Your total is: "+sum;
            }
            else
                richTextBox1.Text = "You ordered a " + crust + " crust pizza with  " + br + " toppings: " + s + "\n Your total is: " + sum; ;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
