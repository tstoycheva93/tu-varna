﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Upr3Zad2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("C");
            comboBox1.Items.Add("F");
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a;
            double ans;
            a = Double.Parse(textBox1.Text);

            if (comboBox1.Text == "C") {
                ans = (a * 9) / 5 + 32;
                textBox2.Text = Math.Round(ans, 2).ToString() + " F";
            }
            else if (comboBox1.Text == "F") {
                ans = (a - 32) * 5.00 / 9.00;
                textBox2.Text = Math.Round(ans,2).ToString() + " C";
            }
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.' &&
            e.KeyChar != '-')
            {
                e.Handled = true; textBox1.Focus();
            }
        }
    }
}
