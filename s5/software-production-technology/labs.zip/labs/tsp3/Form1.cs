namespace tsp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text = "a";
            label2.Text = "b";
            label3.Text = "res";
            radioButton1.Text = "(a+b)^2";
            radioButton2.Text = "(a-b)^2";
            radioButton3.Text = "(a+b)*(a-b)";
            radioButton4.Text = "(a+b)^3";
            radioButton5.Text = "(a-b)^3";
            radioButton6.Text = "a^3-b^3";
            radioButton7.Text = "a^3+b^3";
            button1.Text = "Sumbit";
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b, Result;
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            if (radioButton1.Checked)
            {
                Result = Math.Pow((a + b), 2);
                textBox3.Text = Result.ToString();
            }
            if (radioButton2.Checked)
            {
                Result = Math.Pow((a - b), 2);
                textBox3.Text = Result.ToString();
            }
            if (radioButton3.Checked)
            {
                Result = (a+b)*(a-b);
                textBox3.Text = Result.ToString();
            }
            if (radioButton4.Checked)
            {
                Result = Math.Pow((a + b), 3);
                textBox3.Text = Result.ToString();
            }
            if (radioButton5.Checked)
            {
                Result = Math.Pow((a - b), 3);
                textBox3.Text = Result.ToString();
            }
            if (radioButton6.Checked)
            {
                Result = Math.Pow(a, 3) - Math.Pow(b, 3);
                textBox3.Text = Result.ToString();
            }
            if (radioButton7.Checked)
            {
                Result = Math.Pow(a, 3) + Math.Pow(b, 3);
                textBox3.Text = Result.ToString();
            }
            }
    }
}
