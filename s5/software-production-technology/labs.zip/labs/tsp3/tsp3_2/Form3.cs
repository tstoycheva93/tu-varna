﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tsp3_2
{

    public partial class Form3 : Form
    {
        public static Random random;
        public static List<int> lottoNumbers = Enumerable.Range(1, 35).ToList();
        public Form3()
        {
            InitializeComponent();
            button1.Text = "Try!";
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        public static void GenerateNumbers(int LineCount)
        {
            int[] SelectedNumbers = new int[5];
            for (var i = 0; i < 5; i++)
            {
                var number = GetRandomNumber(lottoNumbers.ToArray());
                while (SelectedNumbers.Contains(number))
                    number = GetRandomNumber(lottoNumbers.ToArray());
                SelectedNumbers[i] = number;
            }
            var numbersOrdered = SelectedNumbers.OrderBy(n => n).Select(n => n.ToString().PadLeft(2,
            '0'));
            MessageBox.Show(string.Join(" ", numbersOrdered));
            if (LineCount > 1) GenerateNumbers(--LineCount);
        }
        public static int GetRandomNumber(int[] arr)
        {
            if (arr.Length > 1)
            {
                var r = random.Next(0, arr.Length);
                var list = arr.ToList();
                list.RemoveAt(r);
                return GetRandomNumber(list.ToArray());
            }
            return arr[0];
        } 

            private void button1_Click(object sender, EventArgs e)
        {
            random = new Random((int)DateTime.Now.Ticks);
            var LinesToGenerate = 1; GenerateNumbers(LinesToGenerate);

        }
    }
}
