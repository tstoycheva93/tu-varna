﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tsp3_2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            button1.Text = "Check";
            button2.Text = "Clear";
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dd = new DateTime();
            dd = DateTime.Parse(dateTimePicker1.Text);
            string Message = "\nDay=" + dd.Day + "\nMonth=" + dd.Month +
            "\nYear=" + dd.Year + "\nDayOfWeek=" + dd.DayOfWeek +
            "\nDayOfYear=" + dd.DayOfYear;
            string Message1 = "30 Day";
            string Message2 = "31 Day";
            string Message3 = "28 Day";
            string Message4 = "29 Day";
            int mm = dd.Month;
            switch (mm)
            {
                case 1:
                    MessageBox.Show(Message + "\n" + Message2);
                   break;
                case 2:
                    if (DateTime.IsLeapYear(dd.Year))
                    {
                        MessageBox.Show("Leap Year! " + Message + "\n" + Message4);
                    }
                    else
                    {
                        MessageBox.Show("Not a Leap Year! " + Message + "\n" + Message3);
                    }
                    break;
                case 3:
                    MessageBox.Show(Message + "\n" + Message2);
                    break;
                case 4:
                    MessageBox.Show(Message + "\n" + Message1);
                    break;
                case 5:
                    MessageBox.Show(Message + "\n" + Message2);
                    break;
                case 6:
                    MessageBox.Show(Message + "\n" + Message1);
                    break;
                case 7:
                    MessageBox.Show(Message + "\n" + Message2);
                    break;
                case 8:
                    MessageBox.Show(Message + "\n" + Message2);
                    break;
                case 9:
                    MessageBox.Show(Message + "\n" + Message1);
                    break;
                case 10:
                    MessageBox.Show(Message + "\n" + Message2);
                    break;
                case 11:
                    MessageBox.Show(Message + "\n" + Message1);
                    break;
                case 12:
                    MessageBox.Show(Message + "\n" + Message2);
                    break;
            }
        }
    }
}
