﻿using System.Globalization;

namespace tsp3_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Salary";
            // DDO - Income tax
            label2.Text = "DOO";
            // DZPO - The additional obligatory pension insurance
            label3.Text = "DZPO";
            label4.Text = "Health Insurance";
            label5.Text = "Total";
            radioButton1.Text = "Before 1960 year";
            radioButton1.Checked = true;
            radioButton2.Text = "After 01.01.1960 year";
            label6.ResetText();
            label7.ResetText();
            label8.ResetText();
            label9.ResetText();
            groupBox1.Text = "Year of birth";
            button1.Text = "Calculate";
        }
        string BGL = "";
        void ShowAmmount(double aAmmount, CultureInfo aCulture)
        {
            BGL = String.Format(aCulture, "{0:C}", aAmmount);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double pDDO, pDZPO, Salary, DOO, DZPO, Total, HI;
            if (radioButton1.Checked)
            {
                pDDO = 0.089; pDZPO = 0;
                Salary = Convert.ToDouble(textBox1.Text);
                DOO = pDDO * Salary;
                ShowAmmount(DOO, new CultureInfo("bg-BG"));
                label6.Text = BGL;
                DZPO = pDZPO * Salary;
                ShowAmmount(DZPO, new CultureInfo("bg-BG"));
                label7.Text = BGL;
                HI = 0.032 * Salary;
                ShowAmmount(HI, new CultureInfo("bg-BG"));
                label8.Text = BGL;
                Total = DOO + DZPO + HI;
                ShowAmmount(Total, new CultureInfo("bg-BG"));
                label9.Text = BGL;
            }
            if (radioButton2.Checked)
            {
                pDDO = 0.067; pDZPO = 0.022;
                Salary = Convert.ToDouble(textBox1.Text);
                DOO = pDDO * Salary;
                ShowAmmount(DOO, new CultureInfo("bg-BG"));
                label6.Text = BGL;
                DZPO = pDZPO * Salary;
                ShowAmmount(DZPO, new CultureInfo("bg-BG"));
                label7.Text = BGL;
                HI = 0.032 * Salary;
                ShowAmmount(HI, new CultureInfo("bg-BG"));
                label8.Text = BGL;
                Total = DOO + DZPO + HI;
                ShowAmmount(Total, new CultureInfo("bg-BG"));
                label9.Text = BGL;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
                if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (Char)Keys.Back && e.KeyChar != '.')
                {
                    e.Handled = true;
                    textBox1.Focus();
                }
        }
    }
}
