using System.Windows.Forms;

namespace hw5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            formLoad();
        }

        private void formLoad()
        {
            listBox1.Items.Clear();
            if (File.Exists("workers.txt"))
            {
                string[] lines = File.ReadAllLines("workers.txt");
                foreach (string line in lines)
                {
                    listBox1.Items.Add(line);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string newRecord = $"{textBox1.Text}";
            listBox1.Items.Add(newRecord);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StreamWriter writer = new StreamWriter("workers.txt");
            foreach (var item in listBox1.Items)
            {
                writer.WriteLine(item.ToString());
            }
            writer.Close();
            MessageBox.Show("Success! Yay!");
        }
    }
}
