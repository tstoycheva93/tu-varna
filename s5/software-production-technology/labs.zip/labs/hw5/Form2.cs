﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hw5
{
    public partial class Form2 : Form
    {
        private int timeLeft;
        private Random random = new Random();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            GenerateQuestions();
        }

        private void GenerateQuestions()
        {
            label1.Text = $"{random.Next(1, 50)} + {random.Next(1, 50)}";
            label2.Text = $"{random.Next(1, 50)} - {random.Next(1, 50)}";
            label3.Text = $"{random.Next(1, 50)} * {random.Next(1, 50)}";
            label4.Text = $"{random.Next(1, 50)} / {random.Next(1, 50)}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timeLeft = 30; // 30 seconds
            timer1.Start();
            label6.Text = $"{timeLeft}";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft--;
                label6.Text = $"{timeLeft}";
            }
            else
            {
                timer1.Stop();
                MessageBox.Show("Timeout!");
            }
        }
    }
}
