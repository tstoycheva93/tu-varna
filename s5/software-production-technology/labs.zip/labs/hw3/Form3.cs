﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hw3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label1.Text = "";
            button1.Text = "Calculate";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime birthDate = dateTimePicker1.Value;
            DateTime today = DateTime.Now;
            int age = today.Year - birthDate.Year;
            int months;
            int days;
            if (today.DayOfYear < birthDate.DayOfYear)
            {
                age--;
                months = 12 + (today.Month - birthDate.Month);
                days = 30 + (today.Day - birthDate.Day);

            }
            else
            {
                months = today.Month - birthDate.Month;
                days = today.Day - birthDate.Day;
            }

            label1.Text = $"Age is {age} years {months} months {days} days";
        }
    }
}
