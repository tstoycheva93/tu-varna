namespace hw3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Interest Calculator";

            label1.Text = "Loan Amount:";
            label2.Text = "Interest Rate:";

            label3.Text = "Daily Interest";
            label4.Text = "Monthly Interest";
            label5.Text = "Yearly Interest";

            button1.Text = "Calculate";

            groupBox1.Text = "";
            radioButton1.Text = "Simple Interest";
            radioButton2.Text = "Compound Interest";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double principal = double.Parse(textBox1.Text);
            double rate = double.Parse(textBox2.Text);

            double daysInYear = 360.0;
            double monthsInYear = 12.0;

            if (radioButton1.Checked)
            {
                label3.Text = CalculateSimpleInterest(principal, rate, 1 / daysInYear).ToString("C");
                label4.Text = CalculateSimpleInterest(principal, rate, 1 / monthsInYear).ToString("C");
                label5.Text = CalculateSimpleInterest(principal, rate, 1).ToString("C");
            }
            else if (radioButton2.Checked)
            {
                label3.Text = CalculateCompoundInterest(principal, rate, 1 / daysInYear).ToString("C");
                label4.Text = CalculateCompoundInterest(principal, rate, 1 / monthsInYear).ToString("C");
                label5.Text = CalculateCompoundInterest(principal, rate, 1).ToString("C");
            }
        }

        private double CalculateSimpleInterest(double principal, double rate, double periodInYears)
        {
            return principal * (1 + (rate * periodInYears) / 100);
        }

        private double CalculateCompoundInterest(double principal, double rate, double periodInYears)
        {
            return principal * Math.Pow(1 + rate / 100, periodInYears);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
