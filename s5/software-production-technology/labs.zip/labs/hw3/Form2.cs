﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hw3
{
    public partial class Form2 : Form
    {
        private char currentPlayer = 'X';
        private Button[] buttons;
        public Form2()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            buttons = new Button[] { button1, button2, button3, button4, button5, button6, button7, button8, button9 };
            foreach (Button button in buttons)
            {
                button.Click += button_Click;
                button.Text = "";
            }

            label1.Text = $"Current Player: {currentPlayer}";
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            button10.Text = "Reset";
            this.Text = "Tic Tac Toe";

        }

        private void button_Click(object sender, EventArgs e)
        {
            Button buttonClicked = sender as Button;

            if (buttonClicked.Text == "")
            {
                buttonClicked.Text = currentPlayer.ToString();
                if (CheckForWin())
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Game Over");
                }
                else if (CheckForDraw())
                {
                    MessageBox.Show("It's a draw!", "Game Over");
                }
                else
                {
                    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                    label1.Text = $"Current Player: {currentPlayer}";
                }
            }

        }

        private bool CheckForWin()
        {
            return (buttons[0].Text == currentPlayer.ToString() && buttons[1].Text == currentPlayer.ToString() && buttons[2].Text == currentPlayer.ToString()) ||
                   (buttons[3].Text == currentPlayer.ToString() && buttons[4].Text == currentPlayer.ToString() && buttons[5].Text == currentPlayer.ToString()) ||
                   (buttons[6].Text == currentPlayer.ToString() && buttons[7].Text == currentPlayer.ToString() && buttons[8].Text == currentPlayer.ToString()) ||
                   (buttons[0].Text == currentPlayer.ToString() && buttons[3].Text == currentPlayer.ToString() && buttons[6].Text == currentPlayer.ToString()) ||
                   (buttons[1].Text == currentPlayer.ToString() && buttons[4].Text == currentPlayer.ToString() && buttons[7].Text == currentPlayer.ToString()) ||
                   (buttons[2].Text == currentPlayer.ToString() && buttons[5].Text == currentPlayer.ToString() && buttons[8].Text == currentPlayer.ToString()) ||
                   (buttons[0].Text == currentPlayer.ToString() && buttons[4].Text == currentPlayer.ToString() && buttons[8].Text == currentPlayer.ToString()) ||
                   (buttons[2].Text == currentPlayer.ToString() && buttons[4].Text == currentPlayer.ToString() && buttons[6].Text == currentPlayer.ToString());
        }

        private bool CheckForDraw()
        {
            foreach (Button button in buttons)
            {
                if (button.Text == "")
                {
                    return false;
                }
            }
            return true;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            foreach (Button button in buttons)
            {
                button.Text = "";
            }
            currentPlayer = 'X';
            label1.Text = $"Current Player: {currentPlayer}";
        }
    }
}
