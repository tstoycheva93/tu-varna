﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tsp4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.Text = "ASCII";
            label1.Text = "Word:";
            button1.Text = "Check";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name;
            int letter;
            name = textBox1.Text;
            for (int index = 0; index < name.Length; index++)
            {
                letter = name[index];
                listBox1.Items.Add(letter + "");

            }
        }
    }
}
