﻿using System;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

namespace tsp4
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private async void Form4_Load(object sender, EventArgs e)
        {
            await webView21.EnsureCoreWebView2Async();

            webView21.Source = new Uri("https://www.google.com");
            button1.Text = "Back";
            button2.Text = "Forward";
            button3.Text = "Refresh";
            button4.Text = "Go";
            button5.Text = "Stop";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (webView21.CanGoBack)
                webView21.GoBack();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (webView21.CanGoForward)
                webView21.GoForward();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            webView21.Reload();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Uri.TryCreate(textBox1.Text, UriKind.Absolute, out Uri resultUri))
            {
                webView21.Source = resultUri;
            }
            else
            {
                MessageBox.Show("Enter a valid URL.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            webView21.Stop();
        }
    }
}
