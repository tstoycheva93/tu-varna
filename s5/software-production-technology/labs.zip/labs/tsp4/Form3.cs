﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tsp4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            groupBox1.Text = "Size";
            groupBox2.Text = "Crust";
            checkBox1.Text = "Extra cheese";
            button1.Text = "Calculate";
            label1.Text = "Toppings - $1 each";
            radioButton1.Text = "Small";
            radioButton2.Text = "Medium";
            radioButton3.Text = "Large";
            radioButton4.Text = "Thin";
            radioButton5.Text = "Thick";
            string[] lines = System.IO.File.ReadAllLines("C:\\Users\\stoyc\\Documents\\university\\s5\\технология на софтуерното производство\\labs\\tsp4\\test.txt");
            foreach (string str in lines)
            {
                checkedListBox1.Items.Add(str);
            }



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double br = 0;
            double sum = 0;
            string s = "";
            string crust = "";
            for (int x = 0; x < checkedListBox1.Items.Count; x++)
            {
                if (checkedListBox1.GetItemChecked(x))
                {
                    br++;
                    s = s + checkedListBox1.Items[x].ToString() + ", ";
                }
            }
            sum = sum + br;
            if (radioButton1.Checked)
            {
                sum = sum + 9.25;
            }
            else if (radioButton2.Checked)
            {
                sum = sum + 11.50;
            }
            else if (radioButton3.Checked)
            {
                sum = sum + 13.75;
            }
            if (checkBox1.Checked)
            {
                sum = sum + 1.50;
            }
            if (radioButton4.Checked)
            {
                crust = "thin";
            }
            else
                crust = "thick";

            if (checkBox1.Checked)
            {
                sum = sum + 1.50;
                richTextBox1.Text = "You ordered a " + crust + " crust pizza with extra cheese and " + br + " toppings: " + s + "\n Your total is: " + sum;
            }
            else
                richTextBox1.Text = "You ordered a " + crust + " crust pizza with  " + br + " toppings: " + s + "\n Your total is: " + sum; ;
        }
    }
}
