namespace tsp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class StringHelper
        {
            public static string ReverseString(string s)
            {
                char[] arr = s.ToCharArray();
                Array.Reverse(arr);
                return new string(arr);
            }
        }
            private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Enter a word";
            textBox1.Text = "madam";
            label2.Text = "";
            button1.Text = "Check";
            this.Text = "Palindrome";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s1, s2;
            s1 = s2 = textBox1.Text;
            s1 = StringHelper.ReverseString(s1);
            if (s1 == s2)
                label2.Text = "A palindrome!";
            else
                label2.Text = "Not a palindrome!";
        }
    }
}
