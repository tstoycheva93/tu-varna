﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace hw2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = "x";
            label2.Text = "a";
            label3.Text = "b";
            button1.Text = "Calculate";
            this.Text = "Logarithm";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b, x;

            bool isAValid = double.TryParse(textBox2.Text, out a);
            bool isBValid = double.TryParse(textBox3.Text, out b);
            bool isXValid = double.TryParse(textBox1.Text, out x);

            if (isAValid && isBValid && !isXValid)
            {
                //X = log_a(b)
                textBox1.Text = (Math.Log(b) / Math.Log(a)).ToString("0.##");
            }
            else if (isAValid && isXValid && !isBValid)
            {
                //b = a^X
                textBox3.Text = Math.Pow(a, x).ToString("0.##");
            }
            else if (isBValid && isXValid && !isAValid)
            {
                //a = b^(1/X)
                textBox2.Text = Math.Pow(b, 1 / x).ToString("0.##");
            }
            else
            {
                MessageBox.Show("Please enter values for two variables only.");
            }

        }

    }
}
