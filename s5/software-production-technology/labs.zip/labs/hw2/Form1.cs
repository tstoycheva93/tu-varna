namespace hw2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.AddRange(new string[] { "Decimal", "Binary", "Octal", "Hexadecimal" });
            comboBox2.Items.AddRange(new string[] { "Decimal", "Binary", "Octal", "Hexadecimal" });
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 1;
            label1.Text = "Number:";
            button1.Text = "Convert";
            this.Text = "Converter";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int baseFrom = GetBase(comboBox1.SelectedItem.ToString());
            int baseTo = GetBase(comboBox2.SelectedItem.ToString());
            string input = textBox1.Text;

            int number = Convert.ToInt32(input, baseFrom);
            string result = Convert.ToString(number, baseTo);

            textBox2.Text = result.ToUpper();

        }

        private int GetBase(string baseName)
        {
            return baseName switch
            {
                "Binary" => 2,
                "Octal" => 8,
                "Decimal" => 10,
                "Hexadecimal" => 16,
                _ => 10
            };
        }
    }
}
