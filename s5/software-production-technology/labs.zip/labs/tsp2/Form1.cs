namespace tsp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "a="; label2.Text = "b=";
            label3.Text = "c="; label4.Text = "x1=";
            label5.Text = "x2="; button1.Text = "Calculate";
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            double a, b, c, d, x1, x2;
            try
            {
                a = double.Parse(textBox1.Text);
                b = double.Parse(textBox2.Text);
                c = double.Parse(textBox3.Text);
                d = Math.Pow(b, 2) - 4 * a * c;
                if (d >= 0)
                {
                    x1 = (-b + Math.Sqrt(d)) / (2 * a);
                    x2 = (-b - Math.Sqrt(d)) / (2 * a);
                    textBox4.Text = x1.ToString();
                    textBox5.Text = x2.ToString();
                }
                else MessageBox.Show("Error!!!");
            }
            catch
            {
                MessageBox.Show("Error2!!!");
            }

        }
    }
}

