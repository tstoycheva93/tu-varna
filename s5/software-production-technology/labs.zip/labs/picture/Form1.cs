﻿using System.Windows.Forms;

namespace picture
{
    public partial class Form1 : Form
    {
        Bitmap img1 = new Bitmap(@"C:\Users\stoyc\Documents\university\s5\технология на софтуерното производство\labs\picture\img1.png");
        Bitmap img2 = new Bitmap(@"C:\Users\stoyc\Documents\university\s5\технология на софтуерното производство\labs\picture\img2.png");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;

            button1.Text = "Compare!";

            pictureBox1.Image = img1;
            pictureBox2.Image = img2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
      
            if (img1.Width != img2.Width || img1.Height != img2.Height)
            {
                MessageBox.Show("Please use images with equal dimensions.");
                return;
            }
            Bitmap res = new Bitmap(img1.Width, img1.Height);
            for (int x = 0; x < img1.Width; x++)
            {
                for (int y = 0; y < img1.Height; y++)
                {
                    Color pixel1 = img1.GetPixel(x, y);
                    Color pixel2 = img2.GetPixel(x, y);
                    if (pixel1 == pixel2)
                    {
                        res.SetPixel(x, y, Color.White);
                    }
                    else
                    {
                        res.SetPixel(x, y, Color.Red);
                    }
                }
            }
            pictureBox3.Image = res;

        }
    }
}
