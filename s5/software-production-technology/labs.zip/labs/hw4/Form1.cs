namespace hw4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Number:";
            button1.Text = "Generate";
            textBox1.Text = "5";
            this.Text = "Spiral Matrix";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int N;
            if (int.TryParse(textBox1.Text, out N) && N >= 0)
            {
                int size = N + 1;
                int[,] matrix = new int[size, size]; 

                int[] dRow = { 0, -1, 0, 1 };
                int[] dCol = { 1, 0, -1, 0 };

                int row = size / 2; 
                int col = size / 2;
                int directionIndex = 0; 

                for (int num = 0; num <= N; num++)
                {
                    matrix[row, col] = num;

                    int nextRow = row + dRow[directionIndex];
                    int nextCol = col + dCol[directionIndex];

                    if (nextRow < 0 || nextRow >= size || nextCol < 0 || nextCol >= size || matrix[nextRow, nextCol] != 0)
                    {
                        directionIndex = (directionIndex + 1) % 4;
                        nextRow = row + dRow[directionIndex];
                        nextCol = col + dCol[directionIndex];
                    }

                    row = nextRow;
                    col = nextCol;
                }

                string result = "";
                for (int i = 0; i < size; i++)
                {
                    for (int j = 0; j < size; j++)
                    {
                        result += matrix[i, j].ToString() + "\t"; 
                    }
                    result += "\n"; 
                }

                richTextBox1.Text = result; 
            }
            else
            {
                MessageBox.Show("Please enter a valid non-negative integer for N.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
