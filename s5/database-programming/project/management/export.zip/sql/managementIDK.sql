CREATE TABLE absence (
    absence_id          INTEGER NOT NULL,
    reason_id_absence   INTEGER NOT NULL,
    month_id_absence    INTEGER NOT NULL,
    daysnumber          INTEGER
);

ALTER TABLE absence ADD CONSTRAINT absence_pk PRIMARY KEY ( absence_id );

CREATE TABLE attendance (
    attendance_id         INTEGER NOT NULL,
    month_id_attendance   INTEGER NOT NULL,
    daysnumber            INTEGER
);

ALTER TABLE attendance ADD CONSTRAINT attendance_pk PRIMARY KEY ( attendance_id );

CREATE TABLE department (
    department_id     INTEGER NOT NULL,
    department_name   VARCHAR2(60)
);

ALTER TABLE department ADD CONSTRAINT departmenttable_pk PRIMARY KEY ( department_id );

CREATE TABLE employee (
    employee_id       INTEGER NOT NULL,
    employee_name     VARCHAR2(60),
    job_id_employee   INTEGER NOT NULL,
    employee_salary   INTEGER,
    employee_entry    DATE
);

ALTER TABLE employee ADD CONSTRAINT employee_pk PRIMARY KEY ( employee_id );

CREATE TABLE job (
    job_id              INTEGER NOT NULL,
    job_name            VARCHAR2(60),
    department_id_job   INTEGER NOT NULL
);

ALTER TABLE job ADD CONSTRAINT job_pk PRIMARY KEY ( job_id );

CREATE TABLE language (
    language_id     INTEGER NOT NULL,
    language_name   VARCHAR2(60)
);

ALTER TABLE language ADD CONSTRAINT language_pk PRIMARY KEY ( language_id );

CREATE TABLE month (
    month_id     INTEGER NOT NULL,
    month_name   VARCHAR2(60)
);

ALTER TABLE month ADD CONSTRAINT months_pk PRIMARY KEY ( month_id );

CREATE TABLE reason (
    reason_id     INTEGER NOT NULL,
    reason_name   VARCHAR2(60)
);

ALTER TABLE reason ADD CONSTRAINT reason_pk PRIMARY KEY ( reason_id );

CREATE TABLE sheet (
    sheet_id              INTEGER NOT NULL,
    year                  INTEGER,
    employee_id_sheet     INTEGER NOT NULL,
    absence_id_sheet      INTEGER NOT NULL,
    attendance_id_sheet   INTEGER NOT NULL
);

ALTER TABLE sheet ADD CONSTRAINT yearsheet_pk PRIMARY KEY ( sheet_id );

CREATE TABLE skill (
    employee_id_skill   INTEGER NOT NULL,
    language_id_skill   INTEGER NOT NULL
);

ALTER TABLE absence
    ADD CONSTRAINT absence_month_fk FOREIGN KEY ( month_id_absence )
        REFERENCES month ( month_id );

ALTER TABLE absence
    ADD CONSTRAINT absence_reason_fk FOREIGN KEY ( reason_id_absence )
        REFERENCES reason ( reason_id );

ALTER TABLE attendance
    ADD CONSTRAINT attendance_month_fk FOREIGN KEY ( month_id_attendance )
        REFERENCES month ( month_id );

ALTER TABLE employee
    ADD CONSTRAINT employee_job_fk FOREIGN KEY ( job_id_employee )
        REFERENCES job ( job_id );

ALTER TABLE job
    ADD CONSTRAINT job_department_fk FOREIGN KEY ( department_id_job )
        REFERENCES department ( department_id );

ALTER TABLE sheet
    ADD CONSTRAINT sheet_absence_fk FOREIGN KEY ( absence_id_sheet )
        REFERENCES absence ( absence_id );

ALTER TABLE sheet
    ADD CONSTRAINT sheet_attendance_fk FOREIGN KEY ( attendance_id_sheet )
        REFERENCES attendance ( attendance_id );

ALTER TABLE sheet
    ADD CONSTRAINT sheet_employee_fk FOREIGN KEY ( employee_id_sheet )
        REFERENCES employee ( employee_id );

ALTER TABLE skill
    ADD CONSTRAINT skill_employee_fk FOREIGN KEY ( employee_id_skill )
        REFERENCES employee ( employee_id );

ALTER TABLE skill
    ADD CONSTRAINT skill_language_fk FOREIGN KEY ( language_id_skill )
        REFERENCES language ( language_id );
        
ALTER TABLE sheet
MODIFY absence_id_sheet INT NULL;

CREATE OR REPLACE TRIGGER Absence_ID_AUTO_TRG
BEFORE INSERT ON Absence 
FOR EACH ROW 
WHEN (NEW.absence_id IS NULL) 
BEGIN
:NEW.absence_id := SEQUENCE_ABSENCE.NEXTVAL;
END;

Insert into ABSENCE (REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (1,12,30);
        
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (1,1,1,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (2,2,2,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (3,3,3,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (4,4,4,1);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (5,1,5,4);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (6,1,6,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (7,2,7,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (8,3,8,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (9,4,9,1);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (10,1,10,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (11,5,11,1);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (12,2,12,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (13,3,1,2);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (14,5,2,1);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (15,3,3,5);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (16,4,4,7);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (17,3,5,4);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (18,2,6,10);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (19,1,7,3);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (20,5,8,1);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (21,1,9,6);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (22,2,10,7);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (23,5,11,1);
Insert into ABSENCE (ABSENCE_ID,REASON_ID_ABSENCE,MONTH_ID_ABSENCE,DAYSNUMBER) values (24,1,12,3);

CREATE OR REPLACE TRIGGER Attendance_ID_AUTO_TRG
BEFORE INSERT ON Attendance 
FOR EACH ROW 
WHEN (NEW.attendance_id IS NULL) 
BEGIN
:NEW.attendance_id := SEQUENCE_ATTENDANCE.NEXTVAL;
END;

Insert into ATTENDANCE (MONTH_ID_ATTENDANCE,DAYSNUMBER) values (12,30);

Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (25,1,20);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (26,2,20);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (27,3,20);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (1,1,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (2,2,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (3,3,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (4,4,19);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (5,5,16);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (6,6,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (7,7,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (8,8,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (9,9,19);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (10,10,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (11,11,19);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (12,12,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (13,1,18);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (14,2,19);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (15,3,15);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (16,4,13);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (17,5,16);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (18,6,10);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (19,7,17);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (20,8,19);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (21,9,14);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (22,10,13);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (23,11,19);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (24,12,17);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (28,4,20);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (29,5,20);
Insert into ATTENDANCE (ATTENDANCE_ID,MONTH_ID_ATTENDANCE,DAYSNUMBER) values (30,6,20);

CREATE OR REPLACE TRIGGER Employee_ID_AUTO_TRG
BEFORE INSERT ON Employee 
FOR EACH ROW 
WHEN (NEW.employee_id IS NULL) 
BEGIN
:NEW.employee_id := SEQUENCE_EMPLOYEE.NEXTVAL;
END;

Insert into EMPLOYEE (EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values ('TEST',1,5000,to_date('2018-01-01','RRRR-MM-DD'));

Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (1,'Anthony Allen',1,5000,to_date('2018-01-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (2,'Bob Brown',2,4000,to_date('2018-02-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (3,'Catherine Carter',3,6700,to_date('2018-03-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (4,'David Daniels',4,6000,to_date('2018-04-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (5,'Emma Edwards',5,4600,to_date('2018-05-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (6,'Frank Foster',1,5200,to_date('2018-06-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (7,'Grace Green',3,4800,to_date('2018-07-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (8,'Hannah Harris',3,5300,to_date('2018-08-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (9,'Isaac Irvine',4,4900,to_date('2018-09-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (10,'Jack Jackson',5,4500,to_date('2018-10-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (11,'Kathy King',3,5000,to_date('2018-11-01','RRRR-MM-DD'));
Insert into EMPLOYEE (EMPLOYEE_ID,EMPLOYEE_NAME,JOB_ID_EMPLOYEE,EMPLOYEE_SALARY,EMPLOYEE_ENTRY) values (12,'Leo Lewis',3,4000,to_date('2018-12-01','RRRR-MM-DD'));

CREATE OR REPLACE TRIGGER Department_ID_AUTO_TRG
BEFORE INSERT ON Department 
FOR EACH ROW 
WHEN (NEW.department_id IS NULL) 
BEGIN
:NEW.department_id := SEQUENCE_DEPARTMENT.NEXTVAL;
END;

Insert into DEPARTMENT (DEPARTMENT_NAME) values ('TEST');


Insert into DEPARTMENT (DEPARTMENT_ID,DEPARTMENT_NAME) values (1,'Management');
Insert into DEPARTMENT (DEPARTMENT_ID,DEPARTMENT_NAME) values (2,'Sales');
Insert into DEPARTMENT (DEPARTMENT_ID,DEPARTMENT_NAME) values (3,'Finance');

CREATE OR REPLACE TRIGGER Job_ID_AUTO_TRG
BEFORE INSERT ON Job 
FOR EACH ROW 
WHEN (NEW.job_id IS NULL) 
BEGIN
:NEW.job_id := SEQUENCE_JOB.NEXTVAL;
END;

Insert into JOB (JOB_NAME,DEPARTMENT_ID_JOB) values ('TEST',1);

Insert into JOB (JOB_ID,JOB_NAME,DEPARTMENT_ID_JOB) values (1,'HR Manager',1);
Insert into JOB (JOB_ID,JOB_NAME,DEPARTMENT_ID_JOB) values (2,'Recruiter',1);
Insert into JOB (JOB_ID,JOB_NAME,DEPARTMENT_ID_JOB) values (3,'Sales Representative',2);
Insert into JOB (JOB_ID,JOB_NAME,DEPARTMENT_ID_JOB) values (4,'Sales Manager',2);
Insert into JOB (JOB_ID,JOB_NAME,DEPARTMENT_ID_JOB) values (5,'Accountant',3);

CREATE OR REPLACE TRIGGER Language_ID_AUTO_TRG
BEFORE INSERT ON Language 
FOR EACH ROW 
WHEN (NEW.language_id IS NULL) 
BEGIN
:NEW.language_id := SEQUENCE_LANGUAGE.NEXTVAL;
END;

Insert into LANGUAGE (LANGUAGE_NAME) values ('TEST');

Insert into LANGUAGE (LANGUAGE_ID,LANGUAGE_NAME) values (1,'English');
Insert into LANGUAGE (LANGUAGE_ID,LANGUAGE_NAME) values (2,'French');
Insert into LANGUAGE (LANGUAGE_ID,LANGUAGE_NAME) values (3,'Spanish');
Insert into LANGUAGE (LANGUAGE_ID,LANGUAGE_NAME) values (4,'German');
Insert into LANGUAGE (LANGUAGE_ID,LANGUAGE_NAME) values (5,'Japanese');

CREATE OR REPLACE TRIGGER Reason_ID_AUTO_TRG
BEFORE INSERT ON Reason 
FOR EACH ROW 
WHEN (NEW.reason_id IS NULL) 
BEGIN
:NEW.reason_id := SEQUENCE_REASON.NEXTVAL;
END;

Insert into REASON (REASON_NAME) values ('TEST');

Insert into REASON (REASON_ID,REASON_NAME) values (1,'Sick Leave');
Insert into REASON (REASON_ID,REASON_NAME) values (2,'Paid Leave');
Insert into REASON (REASON_ID,REASON_NAME) values (3,'Personal Leave');
Insert into REASON (REASON_ID,REASON_NAME) values (4,'Training');
Insert into REASON (REASON_ID,REASON_NAME) values (5,'Public Holiday');

CREATE OR REPLACE TRIGGER Month_ID_AUTO_TRG
BEFORE INSERT ON Month 
FOR EACH ROW 
WHEN (NEW.month_id IS NULL) 
BEGIN
:NEW.month_id := SEQUENCE_MONTH.NEXTVAL;
END;

Insert into MONTH (MONTH_NAME) values ('TEST');

Insert into MONTH (MONTH_ID,MONTH_NAME) values (1,'January');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (2,'February');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (3,'March');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (4,'April');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (5,'May');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (6,'June');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (7,'July');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (8,'August');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (9,'September');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (10,'October');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (11,'November');
Insert into MONTH (MONTH_ID,MONTH_NAME) values (12,'December');

CREATE OR REPLACE TRIGGER Sheet_ID_AUTO_TRG
BEFORE INSERT ON Sheet 
FOR EACH ROW 
WHEN (NEW.sheet_id IS NULL) 
BEGIN
:NEW.sheet_id := SEQUENCE_SHEET.NEXTVAL;
END;

Insert into SHEET (YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (2555,1,1,1);

Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (1,2018,1,1,1);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (2,2018,1,2,2);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (3,2019,1,19,19);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (4,2018,2,2,2);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (5,2018,2,3,3);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (6,2019,2,20,20);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (7,2018,3,3,3);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (8,2018,3,4,4);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (9,2019,3,21,21);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (10,2018,4,4,4);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (11,2018,4,5,5);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (12,2019,4,22,22);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (13,2018,5,5,5);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (14,2018,5,6,6);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (15,2019,5,23,23);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (16,2018,6,6,6);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (17,2018,6,7,7);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (18,2019,6,24,24);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (19,2018,7,7,7);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (20,2018,7,8,8);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (21,2019,7,13,13);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (22,2018,8,8,8);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (23,2018,8,9,9);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (24,2019,8,14,14);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (25,2018,9,9,9);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (26,2018,9,10,10);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (27,2019,9,15,15);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (28,2018,10,10,10);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (29,2018,10,11,11);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (30,2019,10,16,16);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (31,2018,11,11,11);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (32,2018,11,12,12);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (33,2019,11,17,17);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (34,2018,12,12,12);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (35,2019,12,18,18);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (36,2019,12,19,19);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (37,2019,1,null,25);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (38,2019,2,null,25);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (39,2019,3,null,26);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (40,2019,4,null,26);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (41,2019,5,null,27);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (42,2019,6,null,27);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (43,2019,7,null,28);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (44,2019,8,null,28);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (45,2019,9,null,29);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (46,2019,10,null,29);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (47,2019,11,null,30);
Insert into SHEET (SHEET_ID,YEAR,EMPLOYEE_ID_SHEET,ABSENCE_ID_SHEET,ATTENDANCE_ID_SHEET) values (48,2019,12,null,30);

Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (1,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (1,2);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (2,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (3,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (3,3);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (4,2);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (5,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (5,4);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (6,2);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (6,3);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (7,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (8,4);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (8,5);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (9,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (10,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (11,2);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (12,1);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (12,4);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (11,3);
Insert into SKILL (EMPLOYEE_ID_SKILL,LANGUAGE_ID_SKILL) values (11,1);


-------------------------------------------------------------------PROCEDURI INSERT-------------------------------------------------------------------------------------------------------------------------------
-- Procedure for absence table
CREATE OR REPLACE PROCEDURE Absence_INSERT(
    v_absence_id         absence.absence_id%TYPE,
    v_reason_id_absence  absence.reason_id_absence%TYPE,
    v_month_id_absence   absence.month_id_absence%TYPE,
    v_daysnumber         absence.daysnumber%TYPE
)
AS
BEGIN
    INSERT INTO absence(absence_id, reason_id_absence, month_id_absence, daysnumber)
    VALUES (v_absence_id, v_reason_id_absence, v_month_id_absence, v_daysnumber);
END;
/

-- Procedure for attendance table
CREATE OR REPLACE PROCEDURE Attendance_INSERT(
    v_attendance_id       attendance.attendance_id%TYPE,
    v_month_id_attendance attendance.month_id_attendance%TYPE,
    v_daysnumber          attendance.daysnumber%TYPE
)
AS
BEGIN
    INSERT INTO attendance(attendance_id, month_id_attendance, daysnumber)
    VALUES (v_attendance_id, v_month_id_attendance, v_daysnumber);
END;
/

-- Procedure for department table
CREATE OR REPLACE PROCEDURE Department_INSERT(
    v_department_id   department.department_id%TYPE,
    v_department_name department.department_name%TYPE
)
AS
BEGIN
    INSERT INTO department(department_id, department_name)
    VALUES (v_department_id, v_department_name);
END;
/

-- Procedure for employee table
CREATE OR REPLACE PROCEDURE Employee_INSERT(
    v_employee_id       employee.employee_id%TYPE,
    v_employee_name     employee.employee_name%TYPE,
    v_job_id_employee   employee.job_id_employee%TYPE,
    v_employee_salary   employee.employee_salary%TYPE,
    v_employee_entry    employee.employee_entry%TYPE
)
AS
BEGIN
    INSERT INTO employee(employee_id, employee_name, job_id_employee, employee_salary, employee_entry)
    VALUES (v_employee_id, v_employee_name, v_job_id_employee, v_employee_salary, v_employee_entry);
END;
/

-- Procedure for job table
CREATE OR REPLACE PROCEDURE Job_INSERT(
    v_job_id             job.job_id%TYPE,
    v_job_name           job.job_name%TYPE,
    v_department_id_job  job.department_id_job%TYPE
)
AS
BEGIN
    INSERT INTO job(job_id, job_name, department_id_job)
    VALUES (v_job_id, v_job_name, v_department_id_job);
END;
/

-- Procedure for language table
CREATE OR REPLACE PROCEDURE Language_INSERT(
    v_language_id     language.language_id%TYPE,
    v_language_name   language.language_name%TYPE
)
AS
BEGIN
    INSERT INTO language(language_id, language_name)
    VALUES (v_language_id, v_language_name);
END;
/

-- Procedure for month table
CREATE OR REPLACE PROCEDURE Month_INSERT(
    v_month_id     month.month_id%TYPE,
    v_month_name   month.month_name%TYPE
)
AS
BEGIN
    INSERT INTO month(month_id, month_name)
    VALUES (v_month_id, v_month_name);
END;
/

-- Procedure for reason table
CREATE OR REPLACE PROCEDURE Reason_INSERT(
    v_reason_id     reason.reason_id%TYPE,
    v_reason_name   reason.reason_name%TYPE
)
AS
BEGIN
    INSERT INTO reason(reason_id, reason_name)
    VALUES (v_reason_id, v_reason_name);
END;
/

-- Procedure for sheet table
CREATE OR REPLACE PROCEDURE Sheet_INSERT(
    v_sheet_id             sheet.sheet_id%TYPE,
    v_year                 sheet.year%TYPE,
    v_employee_id_sheet    sheet.employee_id_sheet%TYPE,
    v_absence_id_sheet     sheet.absence_id_sheet%TYPE,
    v_attendance_id_sheet  sheet.attendance_id_sheet%TYPE
)
AS
BEGIN
    INSERT INTO sheet(sheet_id, year, employee_id_sheet, absence_id_sheet, attendance_id_sheet)
    VALUES (v_sheet_id, v_year, v_employee_id_sheet, v_absence_id_sheet, v_attendance_id_sheet);
END;
/

-- Procedure for skill table
CREATE OR REPLACE PROCEDURE Skill_INSERT(
    v_employee_id_skill   skill.employee_id_skill%TYPE,
    v_language_id_skill   skill.language_id_skill%TYPE
)
AS
BEGIN
    INSERT INTO skill(employee_id_skill, language_id_skill)
    VALUES (v_employee_id_skill, v_language_id_skill);
END;
/

-------------------------------------------------------------------PROCEDURI UPDATE-------------------------------------------------------------------------------------------------------------------------------
-- Procedure for absence table
CREATE OR REPLACE PROCEDURE Absence_UPD(
    v_absence_id         absence.absence_id%TYPE,
    v_reason_id_absence  absence.reason_id_absence%TYPE,
    v_month_id_absence   absence.month_id_absence%TYPE,
    v_daysnumber         absence.daysnumber%TYPE
)
AS
BEGIN
    UPDATE absence
    SET reason_id_absence = v_reason_id_absence,
        month_id_absence  = v_month_id_absence,
        daysnumber        = v_daysnumber
    WHERE absence_id = v_absence_id;
END;
/

-- Procedure for attendance table
CREATE OR REPLACE PROCEDURE Attendance_UPD(
    v_attendance_id       attendance.attendance_id%TYPE,
    v_month_id_attendance attendance.month_id_attendance%TYPE,
    v_daysnumber          attendance.daysnumber%TYPE
)
AS
BEGIN
    UPDATE attendance
    SET month_id_attendance = v_month_id_attendance,
        daysnumber          = v_daysnumber
    WHERE attendance_id = v_attendance_id;
END;
/

-- Procedure for department table
CREATE OR REPLACE PROCEDURE Department_UPD(
    v_department_id   department.department_id%TYPE,
    v_department_name department.department_name%TYPE
)
AS
BEGIN
    UPDATE department
    SET department_name = v_department_name
    WHERE department_id = v_department_id;
END;
/

-- Procedure for employee table
CREATE OR REPLACE PROCEDURE Employee_UPD(
    v_employee_id       employee.employee_id%TYPE,
    v_employee_name     employee.employee_name%TYPE,
    v_job_id_employee   employee.job_id_employee%TYPE,
    v_employee_salary   employee.employee_salary%TYPE,
    v_employee_entry    employee.employee_entry%TYPE
)
AS
BEGIN
    UPDATE employee
    SET employee_name     = v_employee_name,
        job_id_employee   = v_job_id_employee,
        employee_salary   = v_employee_salary,
        employee_entry    = v_employee_entry
    WHERE employee_id = v_employee_id;
END;
/

-- Procedure for job table
CREATE OR REPLACE PROCEDURE Job_UPD(
    v_job_id             job.job_id%TYPE,
    v_job_name           job.job_name%TYPE,
    v_department_id_job  job.department_id_job%TYPE
)
AS
BEGIN
    UPDATE job
    SET job_name           = v_job_name,
        department_id_job  = v_department_id_job
    WHERE job_id = v_job_id;
END;
/

-- Procedure for language table
CREATE OR REPLACE PROCEDURE Language_UPD(
    v_language_id     language.language_id%TYPE,
    v_language_name   language.language_name%TYPE
)
AS
BEGIN
    UPDATE language
    SET language_name = v_language_name
    WHERE language_id = v_language_id;
END;
/

-- Procedure for month table
CREATE OR REPLACE PROCEDURE Month_UPD(
    v_month_id     month.month_id%TYPE,
    v_month_name   month.month_name%TYPE
)
AS
BEGIN
    UPDATE month
    SET month_name = v_month_name
    WHERE month_id = v_month_id;
END;
/

-- Procedure for reason table
CREATE OR REPLACE PROCEDURE Reason_UPD(
    v_reason_id     reason.reason_id%TYPE,
    v_reason_name   reason.reason_name%TYPE
)
AS
BEGIN
    UPDATE reason
    SET reason_name = v_reason_name
    WHERE reason_id = v_reason_id;
END;
/

-- Procedure for sheet table
CREATE OR REPLACE PROCEDURE Sheet_UPD(
    v_sheet_id             sheet.sheet_id%TYPE,
    v_year                 sheet.year%TYPE,
    v_employee_id_sheet    sheet.employee_id_sheet%TYPE,
    v_absence_id_sheet     sheet.absence_id_sheet%TYPE,
    v_attendance_id_sheet  sheet.attendance_id_sheet%TYPE
)
AS
BEGIN
    UPDATE sheet
    SET year                 = v_year,
        employee_id_sheet    = v_employee_id_sheet,
        absence_id_sheet     = v_absence_id_sheet,
        attendance_id_sheet  = v_attendance_id_sheet
    WHERE sheet_id = v_sheet_id;
END;
/

-- Procedure for skill table
CREATE OR REPLACE PROCEDURE Skill_UPD(
    v_employee_id_skill   skill.employee_id_skill%TYPE,
    v_language_id_skill   skill.language_id_skill%TYPE
)
AS
BEGIN
    UPDATE skill
    SET language_id_skill = v_language_id_skill
    WHERE employee_id_skill = v_employee_id_skill;
END;
/

-------------------------------------------------------------------PROCEDURI DELETE-------------------------------------------------------------------------------------------------------------------------------
-- Procedure for absence table
CREATE OR REPLACE PROCEDURE Absence_DEL(
    v_absence_id absence.absence_id%TYPE
)
AS
BEGIN
    DELETE FROM absence
    WHERE absence_id = v_absence_id;
END;
/

-- Procedure for attendance table
CREATE OR REPLACE PROCEDURE Attendance_DEL(
    v_attendance_id attendance.attendance_id%TYPE
)
AS
BEGIN
    DELETE FROM attendance
    WHERE attendance_id = v_attendance_id;
END;
/

-- Procedure for department table
CREATE OR REPLACE PROCEDURE Department_DEL(
    v_department_id department.department_id%TYPE
)
AS
BEGIN
    DELETE FROM department
    WHERE department_id = v_department_id;
END;
/

-- Procedure for employee table
CREATE OR REPLACE PROCEDURE Employee_DEL(
    v_employee_id employee.employee_id%TYPE
)
AS
BEGIN
    DELETE FROM employee
    WHERE employee_id = v_employee_id;
END;
/

-- Procedure for job table
CREATE OR REPLACE PROCEDURE Job_DEL(
    v_job_id job.job_id%TYPE
)
AS
BEGIN
    DELETE FROM job
    WHERE job_id = v_job_id;
END;
/

-- Procedure for language table
CREATE OR REPLACE PROCEDURE Language_DEL(
    v_language_id language.language_id%TYPE
)
AS
BEGIN
    DELETE FROM language
    WHERE language_id = v_language_id;
END;
/

-- Procedure for month table
CREATE OR REPLACE PROCEDURE Month_DEL(
    v_month_id month.month_id%TYPE
)
AS
BEGIN
    DELETE FROM month
    WHERE month_id = v_month_id;
END;
/

-- Procedure for reason table
CREATE OR REPLACE PROCEDURE Reason_DEL(
    v_reason_id reason.reason_id%TYPE
)
AS
BEGIN
    DELETE FROM reason
    WHERE reason_id = v_reason_id;
END;
/

-- Procedure for sheet table
CREATE OR REPLACE PROCEDURE Sheet_DEL(
    v_sheet_id sheet.sheet_id%TYPE
)
AS
BEGIN
    DELETE FROM sheet
    WHERE sheet_id = v_sheet_id;
END;
/

-- Procedure for skill table
CREATE OR REPLACE PROCEDURE Skill_DEL(
    v_employee_id_skill skill.employee_id_skill%TYPE,
    v_language_id_skill skill.language_id_skill%TYPE
)
AS
BEGIN
    DELETE FROM skill
    WHERE employee_id_skill = v_employee_id_skill
      AND language_id_skill = v_language_id_skill;
END;
/
-------------------------------------------------------------------TEST NA PROCEDURI-------------------------------------------------------------------------------------------------------------------------------
BEGIN
    -- Insert a new employee
    Employee_INSERT(
        v_employee_id => 101,
        v_employee_name => 'Jane Doe',
        v_job_id_employee => 5,
        v_employee_salary => 5000,
        v_employee_entry => TO_DATE('2024-12-01', 'YYYY-MM-DD')
    );
END;
/

-- Test UPDATE Procedure for Employee Table
BEGIN
    -- Update the inserted employee
    Employee_UPD(
        v_employee_id => 101,
        v_employee_name => 'Jane Smith',
        v_job_id_employee => 6,
        v_employee_salary => 5500,
        v_employee_entry => TO_DATE('2024-12-05', 'YYYY-MM-DD')
    );
END;
/

BEGIN
    -- Delete the employee
    Employee_DEL(v_employee_id => 101);
END;
/

-- Test INSERT Procedure for Job Table
BEGIN
    -- Insert a new job
    Job_INSERT(
        v_job_id => 501,
        v_job_name => 'Software Engineer',
        v_department_id_job => 701
    );

    -- Check the result
    DBMS_OUTPUT.PUT_LINE('Job inserted.');
END;
/

-- Verify the record was inserted
SELECT * FROM job WHERE job_id = 501;

-- Test UPDATE Procedure for Job Table
BEGIN
    -- Update the inserted job
    Job_UPD(
        v_job_id => 501,
        v_job_name => 'Senior Software Engineer',
        v_department_id_job => 702
    );

    -- Check the result
    DBMS_OUTPUT.PUT_LINE('Job updated.');
END;
/

-- Verify the record was updated
SELECT * FROM job WHERE job_id = 501;

-- Test DELETE Procedure for Job Table
BEGIN
    -- Delete the job
    Job_DEL(v_job_id => 501);

    -- Check the result
    DBMS_OUTPUT.PUT_LINE('Job deleted.');
END;
/

-- Verify the record was deleted
SELECT * FROM job WHERE job_id = 501;

-- Test INSERT Procedure for Sheet Table
BEGIN
    -- Insert a new sheet
    Sheet_INSERT(
        v_sheet_id => 201,
        v_year => 2024,
        v_employee_id_sheet => 101,
        v_absence_id_sheet => 301,
        v_attendance_id_sheet => 401
    );

    -- Check the result
    DBMS_OUTPUT.PUT_LINE('Sheet inserted.');
END;
/

-- Verify the record was inserted
SELECT * FROM sheet WHERE sheet_id = 201;

-- Test UPDATE Procedure for Sheet Table
BEGIN
    -- Update the inserted sheet
    Sheet_UPD(
        v_sheet_id => 201,
        v_year => 2025,
        v_employee_id_sheet => 102,
        v_absence_id_sheet => 302,
        v_attendance_id_sheet => 402
    );

    -- Check the result
    DBMS_OUTPUT.PUT_LINE('Sheet updated.');
END;
/

-- Verify the record was updated
SELECT * FROM sheet WHERE sheet_id = 201;

-- Test DELETE Procedure for Sheet Table
BEGIN
    -- Delete the sheet
    Sheet_DEL(v_sheet_id => 201);

    -- Check the result
    DBMS_OUTPUT.PUT_LINE('Sheet deleted.');
END;
/

-- Verify the record was deleted
SELECT * FROM sheet WHERE sheet_id = 201;

-------------------------------------------------------------------------------NORMALN ZAQVKI-------------------------------------------------------------------------------------------------------------------------------
--tursene po otdel
SELECT e.employee_name, e.empl j.job_name, d.department_name
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
JOIN department d ON j.department_id_job = d.department_id
WHERE d.department_name = 'Sales';

--tursene po job name
SELECT e.employee_name, j.job_name, d.department_name
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
JOIN department d ON j.department_id_job = d.department_id
WHERE j.job_name = 'Accountant';

--tursene po job id
SELECT e.employee_name, j.job_name, d.department_name
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
JOIN department d ON j.department_id_job = d.department_id
WHERE e.job_id_employee = 4;

--tursene po ezik
SELECT e.employee_name, 
       j.job_name, 
       LISTAGG(l.language_name, ', ') WITHIN GROUP (ORDER BY l.language_name) AS spoken_languages
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
JOIN skill s ON e.employee_id = s.employee_id_skill
JOIN language l ON s.language_id_skill = l.language_id
WHERE e.employee_id IN (
    SELECT e2.employee_id
    FROM employee e2
    JOIN skill s2 ON e2.employee_id = s2.employee_id_skill
    JOIN language l2 ON s2.language_id_skill = l2.language_id
    WHERE l2.language_name = 'English'
)
GROUP BY e.employee_name, j.job_name;

--tursene po zaplata
SELECT e.employee_name, j.job_name, e.employee_salary
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
WHERE e.employee_salary = 5000;

--posledni 5 naznacheni, podredeni po data
SELECT *
FROM (
    SELECT e.employee_name, e.employee_entry, j.job_name
    FROM employee e
    JOIN job j ON e.job_id_employee = j.job_id
    ORDER BY e.employee_entry DESC
)
WHERE ROWNUM <= 5;

--slujiteli po dlujnost, podredeni po otdel
SELECT e.employee_name, j.job_name, d.department_name
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
JOIN department d ON j.department_id_job = d.department_id
ORDER BY d.department_id; 

--naznacheni slujiteli za period
SELECT e.employee_name, e.employee_entry, j.job_name
FROM employee e
JOIN job j ON e.job_id_employee = j.job_id
WHERE employee_entry BETWEEN TO_DATE('2018-01-01', 'YYYY-MM-DD') AND TO_DATE('2018-10-01', 'YYYY-MM-DD');

-- slujiteli bez otsustviq za daden mesec
SELECT e.employee_name, j.job_name
FROM employee e
JOIN sheet s ON e.employee_id = s.employee_id_sheet
JOIN attendance a ON s.attendance_id_sheet = a.attendance_id
LEFT JOIN absence abs ON s.absence_id_sheet = abs.absence_id
JOIN job j ON e.job_id_employee = j.job_id
WHERE abs.absence_id IS NULL
AND a.month_id_attendance = 1
AND s.year = 2019;

-------------------------------------------------------------------------------ZAQVKI S CURSOR-------------------------------------------------------------------------------------------------------------------------------
--tursene po otdel
CREATE OR REPLACE PROCEDURE emplByDepartment(v_department VARCHAR2)
IS
CURSOR CUR_SELECT - - CUR_SELECT ��� �� ������
IS
SELECT R.REZ_DATE,S.IME_SLUJITEL,R.PRESTOI, R1.ROOM_NUM,
C.CL_NAME
FROM REZERVACIQ R
JOIN SLUJITEL S ON R.SLUJITEL_SLUJITEL_ID=S.SLUJITEL_ID
JOIN ROOMS R1 ON R.ROOMS_ROOM_ID=R1.ROOM_ID
JOIN CLIENT C ON R.CLIENT_CL_ID=C.CL_ID
WHERE S.IME_SLUJITEL = v_IME;
C_R_DATE DATE; -- ���������� �� ����������
C_S_IME VARCHAR2(50);
C_PR NUMBER;
C_ROOM ROOMS.ROOM_NUM%TYPE;
C_CL_NAME CLIENT.CL_NAME%TYPE;
BEGIN � ������ �� �����������
OPEN CUR_SELECT;
LOOP FETCH CUR_SELECT INTO C_R_DATE, C_S_IME, C_PR, C_ROOM,
C_CL_NAME
EXIT WHEN CUR_SELECT%NOTFOUND;
DBMS_OUTPUT.PUT_LINE('RESERVATION Date=>' || ' ' ||
C_R_DATE || ' ' || 'NAME EMPLOYEE=>' || ' ' || C_S_IME || ' ' ||
'PERIOD=>' || ' ' || C_PR|| ' ' || 'Room number=>' || ' ' || C_ROOM|| ' ' ||
'Client=>' || ' ' || C_CL_NAME);
END LOOP;
CLOSE CUR_SELECT; -- ��������� �� �������
END Res_Empl;
/


