#! /bin/bash

./producer &
./consumer &
