#! /bin/bash

./Producer &
./Consumer &
