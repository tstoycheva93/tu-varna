<html>
<head><title>letters</title>
<style>
   form{
        border: 2px solid #ccc;
        margin: 0 auto;
        max-width: 400px;
        padding: 10px;
    }
</style>
</head>
<body>

<FORM name="letters" method="post" action="#" >
<b>Letters generator</b><br><br>
<input type="submit" name="letters" value="Generate">
</form>

<?php
if (isset($_POST["letters"])) {
require_once 'data.php';
foreach ($people as $person) {
    echo "Уважаем" . (mb_substr($person['name'], -1) == 'а' ? "а" : "и") . " " . $person['name'] . ", <br>";
    echo "Имаме удоволствието да Ви поканим на " . $person['event'] . ".<br>";
    echo $person['message'] . "<br>";
    echo "С уважение, " . $person['friend']."!<br><br>";
}
}
?>
<body>
